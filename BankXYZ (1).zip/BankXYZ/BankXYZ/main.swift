//
//  main.swift
//  BankXYZ
//
//  Created by mac on 01/11/20.
//  Copyright © 2020 mac. All rights reserved.
//

import Foundation
let mainObj = BankMainClass()
mainObj.mainBanking()
